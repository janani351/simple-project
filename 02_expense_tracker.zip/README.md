# Personal Expense Tracker
A small browser-based expense tracker.

## Features
- Record an expense name and amount
- Calculate total spending
- Remove entries
- Persist data with localStorage

## Run
Open `index.html` in a browser.
