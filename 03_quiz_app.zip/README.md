# Quick Quiz App
A short multiple-choice quiz built with vanilla JavaScript.

## Features
- Four sample questions
- Immediate answer feedback
- Score summary and restart

## Run
Open `index.html` in a browser.
