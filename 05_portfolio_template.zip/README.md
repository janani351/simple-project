# Developer Portfolio Template
A responsive one-page portfolio starter.

## Sections
- Introduction
- About
- Projects
- Contact

## Personalize before publishing
Update the sample biography, project descriptions, email address and profile links with accurate information. Do not publish placeholder contact details.

## Run
Open `index.html` in a browser.
