# To-Do List App
A simple task manager built with HTML, CSS and JavaScript.

## Features
- Add and delete tasks
- Mark tasks complete
- Save tasks in browser localStorage

## Run
Open `index.html` in a browser. No installation required.
