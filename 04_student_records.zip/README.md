# Student Records Manager
A lightweight student record manager running entirely in the browser.

## Features
- Add student names and roll numbers
- Search records
- Delete records
- Save records in localStorage

## Run
Open `index.html` in a browser. This demo is for learning and does not use a secure database.
